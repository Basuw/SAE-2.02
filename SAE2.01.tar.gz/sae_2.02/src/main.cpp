/**
*\ file main.cpp
*\ brief Ce fichier sert à créer les fonctions appelant les différents réseau et objet
*\ author JACQUELIN Batsien, ASTOLFI Vincent, HODIN Dorian
*\ date 1 avril 2022
*/

#include "liste.hpp"
#include "maillon.hpp"
#include "menu.hpp"
#include "erreur.hpp"
#include "matrice.hpp"
#include <iostream>
#include <vector>

using namespace std;
/**
* \ brief sert à appeler les menus et l'interface de choix de réseau
*/
void test(){
    int nbObjet;
    vector<string> vObjet;
    system("clear");
    cout<< "\033[01;34m########## Bienvenue dans notre jeu ##########\n\n\033[00m";
    //system("sleep 1");
    cout<<"Vous allez créer un tableau d'objet que vous allez pouvoir transformer en d'autre objet.\nPar exemple un Arbre est transformable en planche, une planche en table, etc...\n";
    //system("sleep 3");

    cout<<endl;

    cout<<("\033[01;32mCréation de vos objet :\033[00m\n");
    cout<<("Nombre d'objet que vous voulez dans votre jeu :\t");
    cin>>nbObjet;

    for(int i=0; i<nbObjet; ++i){
        string objet;
        cout<<"\033[01;35mNom de l'objet n°"<<i+1<<" : \033[00m";
        cin>>objet;
        vObjet.push_back(objet);
    }

    cout<<endl;

    cout<<"Votre liste d'objet a été créé avec succés vous allez rentrez dans le jeu\n\033[01;31m5\n";
    system("sleep 1");
    cout<<"4\n";
    system("sleep 1");
    cout<<"3\n";
    system("sleep 1");
	cout<<"2\n";
	system("sleep 1");
	cout<<"1\n\033[00m";
	system("sleep 1");

	system("clear");

	while(true){
		system("clear");
		int choixReseau;
		cout << "\033[01;32mQuel réseau voulez vous utilisez ?\033[00m\n1- Réseau en liste\n2- Réseau en matrice\n0- Quitter\n\033[01;35mVotre choix : \033[00m";
		cin>>choixReseau;

		if(choixReseau==1){
			Liste L1{nbObjet};
			L1.creerList(vObjet);
			int res=1;
			system("clear");
			while(res!=0){
				res=menuBase();
				if(res==1){
					L1.affichListe();
				}
				if(res==2){
					try{
						L1.creerDependense();
					} catch (const InconnueException &e) {
							string choix; 
							cout << "Veuillez choisir un autre objet.\nVoulez vous les affichers pour vous les remémorer ?\nVotre choix (oui/non) :";
							cin>>choix;
							if(choix=="oui"){
								L1.affichListe();
							}else{
								cout<<"Très bien, retour au menu.\n";
								system("sleep 2"); system("clear");
							}
						}
					}
				}
			}

		if(choixReseau==2){
			system("clear");
			Matrice M1{nbObjet,vObjet};
			M1.menu();
		}
		if(choixReseau==0){
			break;
		}
	}
}
/**
* \ brief sert à tester automatiquement les fonctions
*/
void autotest(){
	list<Maillon*> list;
    vector<string> vObjetA;
	Maillon Arbre{"Arbre"};
	Maillon Planche{"Planche"};
	Maillon Baton{"Baton"};
	Maillon Fer{"Fer"};
	Maillon Pioche{"Pioche"};
	Maillon Epee{"Epée"};
	Maillon Table{"Table"};
	Maillon Bouclier{"Bouclier"};
	Maillon Echelle{"Echelle"};
	Maillon Or{"Or"};
	Maillon LingotDor{"Lingot_d'Or"};
	Maillon Boussole{"Boussole"};
	Maillon Couronne{"Couronne"};
	Maillon Armure{"Armure"};
	Maillon Canne{"Canne_à_peche"};
	vObjetA.push_back("Arbre");
	vObjetA.push_back("Planche");
	vObjetA.push_back("Baton");
	vObjetA.push_back("Fer");
	vObjetA.push_back("Pioche");
	vObjetA.push_back("Epée");
	vObjetA.push_back("Table");
	vObjetA.push_back("Bouclier");
	vObjetA.push_back("Echelle");
	vObjetA.push_back("Or");
	vObjetA.push_back("Lingot_d'Or");
	vObjetA.push_back("Boussole");
	vObjetA.push_back("Couronne");
	vObjetA.push_back("Armure");
	vObjetA.push_back("Canne_à_peche");
	cout << "---------- Test avec des listes ----------" << endl;
	Liste L{15};
	L.creerList(vObjetA);
	L.affichListe();
	cout << endl;
	Arbre.creerListeTransfoA(Planche,L.LesMaillons);
	Planche.creerListeTransfoA(Baton,L.LesMaillons);
	Planche.creerListeTransfoA(Table,L.LesMaillons);
	Planche.creerListeTransfoA(Bouclier,L.LesMaillons);
	Baton.creerListeTransfoA(Echelle,L.LesMaillons);
	Baton.creerListeTransfoA(Canne,L.LesMaillons);
	Fer.creerListeTransfoA(Pioche,L.LesMaillons);
	Fer.creerListeTransfoA(Epee,L.LesMaillons);
	Fer.creerListeTransfoA(Boussole,L.LesMaillons);
	Fer.creerListeTransfoA(Armure,L.LesMaillons);
	Table.creerListeTransfoA(Bouclier,L.LesMaillons);
	Table.creerListeTransfoA(Planche,L.LesMaillons);
	Bouclier.creerListeTransfoA(Planche,L.LesMaillons);
	Bouclier.creerListeTransfoA(Table,L.LesMaillons);
	LingotDor.creerListeTransfoA(Or,L.LesMaillons);
	LingotDor.creerListeTransfoA(Couronne,L.LesMaillons);
	Boussole.creerListeTransfoA(Fer,L.LesMaillons);
	Couronne.creerListeTransfoA(Or,L.LesMaillons);
	Couronne.creerListeTransfoA(LingotDor,L.LesMaillons);
	Echelle.creerListeTransfoA(Baton,L.LesMaillons);
	Armure.creerListeTransfoA(Fer,L.LesMaillons);
	Canne.creerListeTransfoA(Baton,L.LesMaillons);	
	Or.creerListeTransfoA(LingotDor,L.LesMaillons);
	Or.creerListeTransfoA(Couronne,L.LesMaillons);
	Arbre.affichTransfoListe();
	Planche.affichTransfoListe();
	Baton.affichTransfoListe();
	Fer.affichTransfoListe();
	try {
	Pioche.affichTransfoListe();
	}
	catch (VideException &e){
		cout << "Pioche n'est pas transformable." << endl;
	}
	try {
	Epee.affichTransfoListe();
	}
	catch (VideException &e){
		cout << "Epée n'est pas transformable." << endl;
	}
	Table.affichTransfoListe();
	Bouclier.affichTransfoListe();
	Echelle.affichTransfoListe();
	Or.affichTransfoListe();
	LingotDor.affichTransfoListe();
	Boussole.affichTransfoListe();
	Couronne.affichTransfoListe();
	Armure.affichTransfoListe();
	Canne.affichTransfoListe();
	cout << "\n---------- Test avec une matrice ----------" << endl;
	Matrice M{15,0,vObjetA};
	M.AfficherTab();
	M.afficherMatrice();
}
/**
* \ brief sert à appeler les fonctions test et autotest définit juste avant
*/
int main(){
	autotest();
	//test();
	return 0;
}
